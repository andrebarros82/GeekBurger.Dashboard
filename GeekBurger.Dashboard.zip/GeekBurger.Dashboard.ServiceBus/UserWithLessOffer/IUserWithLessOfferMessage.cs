﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GeekBurger.Dashboard.ServiceBus.UserWithLessOffer
{
    public interface IUserWithLessOfferMessage : IReceiveMessage
    {

    }
}
