﻿using System;

namespace GeekBurger.Dashboard.Contract
{
    public class UsersRestrictionsDTO
    {
        public int Users { get; set; }
        public string Restrictions { get; set; }
    }
}
